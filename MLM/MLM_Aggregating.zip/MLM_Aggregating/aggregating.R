#loading r dataset
load("HSBALL.RDATA") # opening a Rdata file. 
View(HSBALL) # Checking to see if the  R data file loaded properly.

# We will create an aggregated dataset file where we will regress the average student math achievement score of a school onto the size of the school.
# This looks at the relationship between X and Y at level 2. 



#we are simply going to aggregate the whole dataset instead of choosing 1 or 2 variables to be aggregated

#code

HSBALLagg <-aggregate(HSBALL, by=list(HSBALL$id), 
                      FUN=mean, na.rm=TRUE)
#HSBALLagg is name of new aggregated dataset

#HSBALL is the old dataset we are aggregating

# by = list () tells us what our grouping variable is that we are aggregating across - we specified the id variable in the HSBALL dataset - remember that to specify variables, we first put the dataset, followed by the dollar sign, followed by the variable name.
#FUN stands for function, and FUN = mean dictates we will calculate and return the mean of each variable across the grouping factor
#na.rm = true dictates that we retain only non-missing values.


#getting descriptives for the group mathach and size variables
install.packages("pastecs")
library(pastecs)
stat.desc(HSBALLagg)

#running a regression were we predict classroom math achievement by classroom size 
lm(mathach ~ size, data=HSBALLagg)
