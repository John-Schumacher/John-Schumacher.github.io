#loading dataset
load("HSBALL6a.RDATA")
View(HSBALL6a)

#Setting a 0/1 numerical predictor variable to be a categorical variable - doing this to the female variable
HSBALL6a$female <- as.factor(HSBALL6a$female)

install.packages("lme4")
library(lme4)

install.packages("lmerTest")
library(lmerTest)

install.packages("mlmRev")
library(mlmRev)

#Checking to see if adding a random slope to a level 1 variable improves model fit.
#Need to run two models: 1 without the random slope, and another where it is included. 

#Model 1 (null model) - just including female as a level 1 categorical covariate because I feel like it. 
#Notice we are specifying reml because only the random effects differ and REML is more conservative than ML.
f.null = lmer(mathach ~ female + Cses + (1|id), 
              data=HSBALL6a, REML = T)

summary(f.null)

#Model 2 (alternative model) - everything is the same as model 1, but now we are adding a random effect for Cses to see if adding it improves model fit. We could also add a random effect to female if you wanted to test the pair of random effects together.
f.alt = lmer(mathach ~ female + Cses + (1 + Cses|id), 
             data=HSBALL6a, REML = T)

summary(f.alt)

#How to compare models - this is one way to do a chi^2 test but it switches the models to ML.
comp = anova(f.null,f.alt,test="chisq")
summary(comp)

#Second Method keeping Reml intact - 
#create chi square statistic
x2 = 2*logLik(f.alt,REML=T)-2*logLik(f.null,REML=T)

#Looking at x2 value
x2

#Calculating p-value 
pchisq(x2,df=2,lower.tail=F)

#Not significant so we won't add the random slope from here on out.

#Checking to see if adding a level 2 variable improves model fit. 
#Model 1 (null model) - Everything is the same, but we are now adding a random effect for Cses to see if adding it improves model fit - could also add a random effect to female if you wanted to test the pair of random effects together. 
f.null2 = lmer(mathach ~ female + Cses + (1|id), 
               data=HSBALL6a, REML = F)

summary(f.null2)

#Model 2 (alternative model) - Everything is the same but adding a fixed effect for Cmeanses which is a level 2 variable. 
f.alt2 = lmer(mathach ~ female + Cses + Cmeanses + (1 |id), 
              data=HSBALL6a, REML = F)

summary(f.alt2)

#How to compare models - this is one way to do chi^2 test, but it switches models to ML always, which here is a good thing since reml can only be used when random effects differ and not fixed effects. 
comp2 = anova(f.null2,f.alt2,test="chisq")
summary(comp2)



