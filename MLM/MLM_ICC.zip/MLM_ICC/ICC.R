#step 1 always - Set Working directory

#loading r dataset
load("HSBALL.RDATA") # opening a Rdata file. 
View(HSBALL) # Checking to see if Rdata file loaded properly.


#installing the nlme package
install.packages("nlme")
library(nlme)

#installing the package lme4 which we won't use here but is useful for HLM;
install.packages("lme4")


#code to get Null model to calculate the ICC.

lme(mathach ~ 1,data=HSBALL, random = ~ 1|id, method = "REML")

#formula y ~ 1 denotes this is a intercept only model (or empty model). So we have mathach ~ 1 since mathach is our y

#data=dataset is specifying what dataset to use;

#random is specifying a random effect, and we are saying that the intercept (i.e. 1) is random across the id (level 2 variable);

#method = "REML" specifies the estimation technique is REML, use ML for maximum liklihood

# The default random effects covariance structure (D matrix) is set to unstructured (allowed to take on any value). Note that the default residual correlation matrix (used for repeated measures) is set to identity or null. 



#ICC Results - obtained after running the code - Note nlme provides the SD and not variance. We need to convert the SD to Variance by squaring the value.;

#Residual variance = 6.26^2 = 39.18;
#Tau00 or variance due to differences in DV across our level 2 variable = 2.93^2 = 8.58;
#ICC = 8.58/(39.18 + 8.58) = .18 = 18%;
#Definition - 18% percent of the DV variance can be explained by differences in our level 2 grouping variable.;
#Definition - The average correlation between any two lower level dv scores in the same upper level 2 group is .18. ;

