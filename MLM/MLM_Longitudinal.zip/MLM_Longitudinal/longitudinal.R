
#Running repeated measures/longitudinal models using MLM.

load("gpa.RData")

library(nlme)










#In R it is easiest to specify residual matrix, more difficult to specify random matrix - which defaults to unstructured
#I will not be teaching the technique, but you can change the random matrix by using differing equations
#JOB works a lot better with R than GPA, so we will be using that. 

#null
null<-lme(JOB ~ 1, random = ~1|STUDENT,  gpa, method = "REML")
summary(null)

#Random UN
ra_un<-lme(JOB ~ 1 , random = ~1 + dum2 + dum3 + dum4 + dum5 + dum6|STUDENT, gpa, method = "REML", control=list(maxIter=400))
summary(ra_un)


#Specifying Residual Matrix

#Compound Symmetry  
cs<-lme(JOB ~ 1, random = ~1 |STUDENT, correlation=corCompSymm (form = ~ OCCAS| STUDENT), gpa, method = "REML")
summary(cs)

#specifying AR(1) covariance structure
ar1<-lme(JOB ~ 1 , random = ~1 |STUDENT, correlation=corAR1 (form = ~ OCCAS | STUDENT), gpa, method = "REML")
summary(ar1)

#specifying Unstructured covariance structure
un<-lme(JOB ~ 1 , random = ~1 |STUDENT,  correlation=corSymm (form = ~ OCCAS | STUDENT), gpa, method = "REML")
summary(un)



