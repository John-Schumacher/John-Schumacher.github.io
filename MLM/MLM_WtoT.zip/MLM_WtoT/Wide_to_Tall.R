#Step 1, always, make sure working directory (WD) is set properly.

#loading wide r dataset
load("rwide.RDATA") # opening a Rdata file. 
View(rwide) # Checking to see if Rdata file loaded properly. 

#Wide format is when each lower level gets its own column (e.g., each time point gets a column) and the unique upper level units are placed on distinct rows
#(e.g., each person is placed on a new row). 

#Most individuals are very familiar with the wide format since it is the default format for repeated measures anova in spss.

#The issue with Wide format is that it requires balanced data, that is, an equal number of lower level units per upper level units. If this is not the case, then you will end up with lots of empty cells.

#Thus, when running a HLM model most programs, including SPSS, use the tall format, where each lower level unit is specified on a new row and we have a column indicating the upper level unit it belongs to.


#converting wide r dataset to tall format
install.packages("tidyr")
library(tidyr)
rtall <- gather(rwide, Pupil, Pop, popular1:popular10, factor_key=TRUE)

#notes on this code . . . 

# rwide is name of wide dataset we are converting

#Pupil is name of index column which gives the value of the lower level 1 variable that is tied to the classroom or upper level unit. 

#Pop is the name of the level 1 DV.

#popular1:popular10 tells R that we are collapsing the values in these columns into a single column.

#factor_key=true turns our index column to a factor variable. This is an important part of the process. 

View(rtall)
#This shows us the dataset if working in regular R. If in Rstudio a clickable dataset should appear on the righthand side.


#changing index column so that the alpha characters are removed from the column values (i.e., removing the word popular from the Pupil column so only the Pupil number remains)
rtall$Pupil <- as.integer(gsub('[a-zA-Z]', '', rtall$Pupil)) # this removes the letters from the column, but also converts the column to a numeric variable
rtall$Pupil <- as.factor(rtall$Pupil) #converts the new column with only integers back to a factor variable 
View(rtall)

#Save the new Rdataset
save(rtall, file = "rtall.RData")

