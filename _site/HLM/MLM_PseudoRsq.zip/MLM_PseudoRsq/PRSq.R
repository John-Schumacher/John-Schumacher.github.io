load("popular.RDATA") # opening a Rdata file. 
View(popular)

install.packages("lme4") 
#note this should already be installed, and, as such, you shouldn't have to do this.
library(lme4)

install.packages("lmerTest")
#note this should already be installed, and, as such, you shouldn't have to do this.
library(lmerTest)

#Using the popular dataset lets calculate the R^2 of a model with the teachpop variable included.

#Going to calculate this value in three distinct ways. 

#Technique # 1 - Calculating standardized coefficients posthoc from a model with the original raw variables.

#first need to get descriptives for X and Y.
sd(popular$teachpop)
mean(popular$teachpop)
sd(popular$popular)
mean(popular$popular)

#Next run model with the original variables.
technique1 = lmer(popular ~  teachpop + (1 |school), REML = T,
                  data=popular)

#asking for estimates and etcetera. 
summary(technique1)

#finally calculate the standardized betas from the raw betas and sum them (if you have more than 1) to get the pseudo R^2;
#raw beta of teach pop = .5289.
#Standardized BETA = (b*SDx)/SDy.

#So...
#BETA = (0.5289*1.0359847)/1.2259231.
#BETA = 0.446954877.


#Technique # 2 - Converting variables to standardized variables apriori, then running a model with these standardized variables and calculating R^2 from the sum of the coefficients.

#step 1 create the standardized variables.
popular$popz=(popular$popular - 5.3080000)/1.2259231
popular$teachz = (popular$teachpop - 4.4835000)/1.0359847

#step 2 run the model with the standardized variables and sum the coeficients if more than 1.
technique2 = lmer(popz ~  teachz + (1 |school), REML = T,
                  data=popular)

#asking for estimates and etcetera. 
summary(technique2)

#Technique # 3 - Running the null model and the full model separately, and calculating 1 - (alt total residual variance/null total residual variance).

#step 1 - run the null model and get the total residual variance (i.e., tau00 + sigma^2).
technique3a = lmer(popular ~  (1 |school), REML = T,
                   data=popular)

#asking for estimates and etcetera. 
summary(technique3a)
#sigma^2 = 0.6387.
#tau00 = 0.8798.
#empty model = 0.6387+0.8798=1.5185.

#step 2 run the full model and get the total residual variance.
technique3b = lmer(popular ~  teachpop + (1 |school), REML = T,
                   data=popular)

#asking for estimates and etcetera.
summary(technique3b)
#sigma^2 = 0.5862.
#tau00 = 0.2597.
#model 2 = .8459.

#step 3 calculate Pseudo R^2 from 1 - (total residual of full/total residual null).
#Pseudo R2 is estimated to be 1- (.8459/1.5185) = .44.
#This value is the estimated proportional reduction of the prediction error from the empty or null model.

#R^2 at level 1 = (sigma^2null-sigma^alt)/(sigma^2null).
#(.6387-.5862)/.6387 = .08.
#This represents the variance at the pupil level explained by teacher popularity

#Could calculate R^2 at level 2 if we had a level 2 variable, or if we didn't group-mean center the level 1 variable, which we didn't do here, thus could do it for this output if you want. 

#R^2 at level 2 = (tau00 null - tau00 alt)/( tau00 null).

