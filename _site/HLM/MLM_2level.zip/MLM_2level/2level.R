#Running two-level models and ignoring cross-level interactions for now.

#loading dataset
load("hsball5b.RDATA")

#setting a 0/1 numerical predictor variable to a categorical variable - doing this to the female variable
hsball5b$female <- as.factor(hsball5b$female)

# installing and loading packages that can apply the Satterthwaite correction - technically, its the lmerTest package that does this, but it needs the lme4 package to do so.
install.packages("lme4")
library(lme4)
install.packages("lmerTest")
library(lmerTest)

#Running a model with a level 1 variable specified as fixed only. note that REML = FALSE would be ML and that R automatically assumes unstructured which is a good thing when we don't have many variables specified as random.
lv1f = lmer(mathach ~ sesC + (1 |id), REML = TRUE,  data=hsball5b)
summary(lv1f)

#Running a model with a level 1 variable specified as fixed and random 
# Note - R does not produce the covariance UN(0,1) value but instead gives the correlation - all other random effect values are in variance form.
lv1fr = lmer(mathach ~ sesC + (1 + sesC |id), REML = TRUE,  data=hsball5b)
summary(lv1fr)

# Running a model with two level 1 fixed effects and its corresponding fixed interaction effect 
# Note - R uses 0 as the reference value for dummy variables where as SAS and SPSS use 1 as the reference value if specifying as categorical.
lv1interaction = lmer(mathach ~ sesC + female + sesC*female + (1 |id), REML = TRUE,  data=hsball5b)
summary(lv1interaction)

#Running a model with a level 2 variable - fixed only
lv2f = lmer(mathach ~ sizeC + (1 |id), data=hsball5b)
summary(lv2f)

#Running a model with two level 2 variables and their interaction - fixed only
lv2interaction = lmer(mathach ~ sizeC + pracadC + sizeC*pracadC + (1 |id), data=hsball5b)
summary(lv2interaction)

#Running a model with a level 2 variable as fixed and random 
# Notice that the random effect of the slope across the intercept is very close to 0 because the variance here is being sucked up with the fixed effect, but this still changes variance across intercept. So this may be useful.
lv1fr = lmer(mathach ~ sizeC + (1 + sizeC |id), REML = TRUE,  data=hsball5b)
summary(lv1fr)


