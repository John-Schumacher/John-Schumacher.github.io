# Running a three-level model.


#year nested within child nested within school.
#variance between schools = level 3.
#variance within schools between children = level 2.
#variance within schools within children = level 1 or remaining variance between year.
#intercept can vary between schools and between children within schools.

save(threelevelbig, file = "threelevelbig.RData")
load("threelevelbig.RData")


library(lme4)

library(lmerTest)

#running null model
#random statement is specificying a random statement for each school and for each child nested within each school
null<-lmer(math ~ 1 + (1|schoolid) + (1|childid), data = threelevelbig, REML = T)
summary(null)

#phi00 (V00k) = variance between schools (level 3) = .5695.
#tau00 (U0jk) = variance within schools between children (level 2) = .7553.
#sigma2 (Rijk) = variance within schools within children (level 1) = 1.2345.

#Calculating %Variance at each level:.
#level 1 (Rijk): 1.2345/(.5695 + .7553 + 1.2345) = .482 or 48.2%.
#level 2 (U0jk):  .7553/(.5695 + .7553 + 1.2345) = .295 or 29.5%.
#level 3 (V00k):  .5695/(.5695 + .7553 + 1.2345) = .223 or 22.3%.
# total variance = .482 + .295 + .223 = 1.0 or 100%.

#adding in fixed effect
fnr<-lmer(math ~ year + (1|schoolid) + (1|childid), data = threelevelbig, REML = T)
summary(fnr)
# interpreted same as before "as year increases 1 unit the expected . . . 

#adding in random effect at level 2
fr2<-lmer(math ~ year + (1|schoolid) + (1+year|childid), data = threelevelbig, REML = T)
summary(fr2)

#variance parameters.
#phi00 (V00k) = variance between schools (level 3).
#tau00 (U0jk) = variance within schools between children (level 2).
#tau11 (U1jk) = variation in the year coefficient (slope) between children within schools (level 2).
#tau01 covar(U0jk, U1jk) = covariance of the variance within school between children and the variance of the year coefficent within school between children.
#sigma2 (Rijk) = variance within schools within children (level 1).



#adding random effect at both level 2 and level 3
fr23<-lmer(math ~ year + (1+year|schoolid) + (1+year|childid), data = threelevelbig, REML = T)
summary(fr23)
#variance parameters.
#phi00 (V00k) = variance between schools (level 3).
#phi11 (V10k) = variation in the year coefficient (slope) between schools (level 3).
#phi01 covar(V00k, V10k)= covariance of the variance between schools and the variance of the year coefficent between schools (level 3).
#tau00 (U0jk) = variance within schools between children (level 2).
#tau11 (U1jk) = variation in the year coefficient (slope) between children within schools (level 2).
#tau01 covar(U0jk, U1jk) = covariance of the variance within school between children and the variance of the year coefficent within school between children.
#sigma2 (Rijk) = variance within schools within children (level 1).

