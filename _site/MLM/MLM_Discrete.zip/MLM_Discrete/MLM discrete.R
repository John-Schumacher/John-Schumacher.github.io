load("HSBALL9b.RDATA")


install.packages("lme4")
library(lme4)

install.packages("mlmRev")
library(mlmRev)


#Going to run a generalized mixed logistic regression.

#empty model
#notice how most everything in this syntax is the same as before;
#method is defaulted to laplace and there is no way to change this in lme4, can use Mass package in R if you want - laplace is an approximation method of ML. 
#in general same rules for ML and REML approximations apply for these generalized mixed models from linear models;
#you must specify dist and link options, or you will likely not run the model you intend to run;
#dist is set to binomial (family = this is where you specify dist) because a dichotomous binary variable is typically thought to follow a binomial distribution.
#link is set to logit (comes in parentheses and quotations after distribution) because that is the most common link for binomial logistic models. I would also argue that most binary variables follow a distribution specified by the natural number and so this is appropriate for most instances;
#residual variance or sigma is not given because the residual variance in a binomial mixed distribution is set to 3.29;

null <- glmer(female ~ 1 + (1|id), family=binomial("logit"), data=hsball9b)
summary(null)

#how do we interpret the intercept in this empty model?;
#The predicted log-odds of being a male across all schools is .10  ;
#predicted probability across all schools of being a male = exp(.10)/1+exp(.10) = .524979 * note that this is is general log odds to probability equation;
# predicted odds across all schools of being a male = exp(.10) = 1.11 otherwise interpreted as for every one female across all the schools we expect 1.11 males;

#how to calculate ICC;
#tau00/(sigma^2 + tau00)
#sigma or residual variance is set to 3.29 always in binary mixed logistic models using a logit link function - not going to discuss this much but it has to do with the binomial distribution having an implied set distribution;
#5.135/(5.135+3.29) = .61;
#how do you interpret this ICC? A little different in theory but not much;
#Of the residual variation in outcomes it is the proportion that is attributable to systematic differences between the level 2 groups (i.e., in our example between schools);

#running full model
full <- glmer(female ~ 1 + meanses + mathach + (1|id), family=binomial("logit"), data=hsball9b)
summary(full)

#interpret meanses estimate;
#have the class do this in their notes;

#interpret mathach estimate;
#have the class do this in their notes;

#calculate variance explained;
#R^2 dichotomous = sigma^2f/(sigma^2f + tau0^2f + sigma^2r) (see slide 62 from discrete outcomes lecture);
#explained part: sigma^2f;
#sigma^F is technically the ovserved variance in the predicted log-odds of the DV that is derived from the regression equation using the IV values;
#unexplained part: tau0^2 (level 2) and sigma^2r (level 1);
#sigma^2r is fixed to 3.29 for logit models and 1 for probit models;
#tau00 is given in model results, here it is equal to 5.013;
#next we need to find sigma^2f by creating a new variable with predicted values and finding the variance of this new variable;

hsball9b$outcome = .5070  - .5201*hsball9b$meanses  - .03266*hsball9b$mathach
var(hsball9b$outcome)

#from the output variance = .13;
#now to calculate R^2 dichotomous...
#.13/(5.013 +3.29+.13) = .0154

