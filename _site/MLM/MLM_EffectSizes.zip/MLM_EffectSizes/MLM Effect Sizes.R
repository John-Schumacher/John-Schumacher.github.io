#remember to set the working directory
load("popular.RDATA") # opening a Rdata file. 
View(popular)

install.packages("lme4")#Note that this should already be installed and, as such, you shouldn't have to do this.
library(lme4)

install.packages("lmerTest")#Note that this should already be installed and, as such, you shouldn't have to do this.
library(lmerTest)

#Using the popular dataset, let's look at the Coen's F of a variable, (going to look at teachpop) from a mixed model.  Let's also calculate PRV (proportional reduction in variance at level 1).


#Cohen's F of teachpop in a model that also has sex in it - no random effects.
#Cohen's F = (R2ab - R2a)/(1-R2ab).

#note that we will cover how to do the Cohen's F with a level 1 variable specified as random first thing next week, which has to be done in SAS.


# step 1 run the null model with no variables and calculate the total residual variance.
step1 = lmer(popular ~   (1 |school), REML = T,
          data=popular)

#asking for estimates and etcetera.
summary(step1)
#sigma^2 = 0.6387.
#tau00 = 0.8798.
#null model = 0.6387+0.8798=1.5185.

#step 2 run a model with all variables (i.e., model ab) included and calculate the total residual variance.
step2 = lmer(popular ~ teachpop + sex +  (1 |school), REML = T,
             data=popular)

#asking for estimates and etcetera.
summary(step2)
#sigma^2 = 0.4367.
#tau00 = 0.4061.
#model ab = 0.4367+0.4061=.8428.

#step3 run a model without the primary predictor we want cohen's F (i.e. model a) for and calculate the total residual variance.
step3 = lmer(popular ~  sex +  (1 |school), REML = T,
             data=popular)

#asking for estimates and etcetera.
summary(step3)
#sigma^2 = 0.4599.
#tau00 = 0.8622.
#model ab = 0.4599+0.8622=1.3221.

#step 4 calculate the pseudo R^2 of model ab.
#Pseudo R2 estimated to be 1- (.8427/1.5185) = .45.

#step 5 calculate the pseudo R^2 of model a.
#Pseudo R2 estimated to be 1- (1.3221/1.5185) = .13.

#step 6 calculate cohen's F.
#Cohen's F = (R2ab - R2a)/(1-R2ab).
#Cohen's F = (.45 - .13)/(1-.45) = .58.

# Let's calculate the PRV of teachpop at level 2 - note that even though teachpop is a level 1 variable, this calculation is possible - also know that people like cohen's F better. We have already covered PRV at level 1 also.

#PRV of teachpop at level 2 = (tau00 model a - tau00 model ab)/tau00 model a.
#PRV of teachpop at level 2 = (0.8622 - 0.4061)/0.8622 = .53
#this can be interpreted as, the variable teachpop explains 53 percent of the level 2 error that exists when teachpop is not included in the model, but all other variables are.
#note that sex is in the model a so this is not the same as saying percent amount of variance at level 2 explained by teachpop.

