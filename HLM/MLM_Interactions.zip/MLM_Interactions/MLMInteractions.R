#Adding cross-level interaction to the model.


load("HSBALL7a.RDATA")
View(HSBALL7a)




install.packages("lme4")
library(lme4)

install.packages("lmerTest")
library(lmerTest)

install.packages("mlmRev")
library(mlmRev)

#Including female Cses and Cmeanses as primary predictors.

#Including female*Cmeanses as a cross-level interaction.

#I am specifying female as random because it is sometimes recommended that you specify any lower-level variable in a cross-level interaction as random - note that this is debatable. 

#Notice how this syntax is how you'd likely expect it to be, that is, you don't do anything special to create a cross-level interaction. 



cl = lmer(mathach ~ female + Cses + Cmeanses + Cmeanses*female + (1 + female|id), REML = T,
          data=HSBALL7a)

#asking for estimates and etcetera. 
summary(cl)

#vcov(object) provides a covariance matrix of the fixed effects - this is useful for things like determining collinearity and if you want to take the square-root of the value to get SE - also needed when we plot the simple effects. 
vcov(cl)