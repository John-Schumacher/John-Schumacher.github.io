# hash tag = the way to comment in R

# Step 1: set working directory (WD) - click file > click change dir > click local disc (C:) > 
#click # users > click your name > click documents > click pick folder you chose > 
#click ok "at bottom # of box" - WD is place where r stores and reads files so that you don't need to specify file path # every time. 

#always set directory; otherwise you will need to specify the full file path.

# when you see code "install()" it means you are installing a package to your R program

# "install()" needs to run for each non-installed package only once per program lifetime

# when you see code "library()" it means you are opening a package in R

# must use "library()" for each package you are using, once every time you open R

# I am listing multiple ways to import .SAV files -  this is because not all ways always work

#Technique #1 
# Importing .sav to r
install.packages("haven")
library(haven)
rdata <- read_spss("HSBALL.sav")
#rdata = name of dataframe/datafile located in r; inputdata.sav = name of spss file 
# the fact that rdata proceeds "<-"is what makes it a dataframe
dim(rdata) #checking to make sure the data imported correctly

#Technique #2
install.packages("foreign")
library(foreign)
db = file.choose() # this will open up explorer folder, find SAS file and select it. db is name of r object, can change this if you want. 
dataset = read.spss(db, to.data.frame=TRUE) #converting this r object to a dataframe so that we can run analyses on it. 
#dataset is name of r dataframe/datafile
dim(dataset) #checking to make sure the data imported correctly

#Technique #3
install.packages("memisc")
library(memisc)
data <- as.data.set(spss.system.file('HSBALL.sav')) #data is name of 
dim(data) #checking to make sure the data imported correctly

# Importing .dat file into R technique number 1
library(foreign)
dc = file.choose()
Rdataset = read.table(dc, header=TRUE)
dim(Rdataset)#checking import

# Importing .dat file into R technique number 2
rdatum <- read.delim("HSBALL.DAT",  header = TRUE, sep = "", as.is=TRUE)
dim(rdatum)

#to check size of database - 2 numbers. 1st = rows/case, 2nd = number of vars/columns
dim(data)

#to inspect first 25 rows (aka observations) of dataset and first 6 columns(aka variables)
head(data)

#to inspect the last six rows of the dataset
tail(data)

#to visualize entire matrix - several ways to do this View(dataset) or fix(dataset) is best for large data table
View(data)
