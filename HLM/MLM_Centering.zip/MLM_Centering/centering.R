load("popular.RDATA") # opening R data file. 
View(popular) # Checking to see if R data file loaded properly.

#getting mean values for level 1 teachpop and level 2 meantpop
#notice that these are the same values
summary(cbind(popular$meantpop, popular$teachpop))



#grand mean centering the level 2 meantpop variable
popular$grandC_meantpop <- popular$meantpop - 4.4835

#grand mean centering the level 1 teachpop variable
popular$grandC_teachpop <- popular$teachpop - 4.4835

#group mean centering the level 1 teachpop variable
popular$groupC_teachpop <- popular$teachpop - popular$meantpop

#installing and loading nlme package to run the mixed model
install.packages("nlme") #should have this installed already but in case you don't run this line
library(nlme) #loading package

#running a mixed model with the grand centered level 2 variable and the group centered level 1 variable
lme(popular ~ grandC_meantpop + groupC_teachpop, random = ~ 1|school, data=popular,  method = "REML")

#running a mixed model with the grand centered level 2 variable and the grand centered level 1 variable
lme(popular ~ grandC_meantpop + grandC_teachpop, random = ~ 1|school, data=popular,  method = "REML")

#Note -  due to intricacies of this data, you cannot run a model with both level 1 centered variables and the level 2 centered variable, due to collinearity. However, in most datasets, you could do this.